<?php
// Silence is golden. And We are agree :)
?>